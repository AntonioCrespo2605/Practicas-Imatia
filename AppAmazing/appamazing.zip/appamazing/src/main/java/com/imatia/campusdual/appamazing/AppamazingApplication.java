package com.imatia.campusdual.appamazing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppamazingApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppamazingApplication.class, args);
	}

}
