package com.imatia.campusdual.appamazing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppamazingApplicationTests {

	@Test
	void contextLoads() {
	}

}
